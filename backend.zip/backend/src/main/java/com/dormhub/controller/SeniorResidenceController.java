package com.dormhub.controller;
public class SeniorResidenceController {
    
}
