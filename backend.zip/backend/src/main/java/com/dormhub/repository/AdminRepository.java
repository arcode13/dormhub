package com.dormhub.repository;

public class AdminRepository {
    
}
