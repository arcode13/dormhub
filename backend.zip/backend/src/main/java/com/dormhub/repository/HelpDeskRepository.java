package com.dormhub.repository;

public class HelpDeskRepository {
    
}
