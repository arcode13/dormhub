package com.dormhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DormHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(DormHubApplication.class, args);
	}

}
