package com.dormhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DormHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
